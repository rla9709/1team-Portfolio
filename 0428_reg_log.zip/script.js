function check_ok() {
	if(document.reg_frm.user_id.value.length == 0){
		alert("아이디를 입력하세요.");
		reg_frm.user_id.focus();
		return;
	}	
	if(document.reg_frm.user_id.value.length < 4){
		alert("아이디는 4글자이상이어야 합니다.");
		reg_frm.user_id.focus();
		return;
	}	
	if(Number(document.reg_frm.user_id.value)){
    	alert("아이디는 숫자만 사용할 수 없습니다.");
		reg_frm.user_id.focus();
		return;
	}	
	if(!/^[a-zA-Z]/.test(document.reg_frm.user_id.value)){
    	alert("아이디는 영문으로 시작해야 합니다.");
		reg_frm.user_id.focus();
		return;
	}
	if(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힝]/.test(document.reg_frm.user_id.value)){
	    alert("아이디 안에 한글은 포함될 수 없습니다.");
		reg_frm.user_id.focus();
		return;
	}
	if(document.reg_frm.user_pw.value.length == 0){
		alert("패스워드는 반드시 입력해야 합니다.");
		reg_frm.user_pw.focus();
		return;
	}	
	if(/(\w)\1\1/.test(document.reg_frm.user_pw.value)){
    	alert('비밀번호안에 같은문자는 3번 이상 사용할 수 없습니다.');
		reg_frm.user_pw.focus();
		return;
	}
	if(/(0123)|(1234)|(2345)|(3456)|(4567)|(5678)|(6789)|(7890)/.test(document.reg_frm.user_pw.value)){
    	alert('비밀번호는 4회이상의 연속된 숫자를 사용할 수 없습니다.');
		reg_frm.user_pw.focus();
		return;
	}
	if(/(0987)|(9876)|(8765)|(7654)|(6543)|(5432)|(4321)|(3210)/.test(document.reg_frm.user_pw.value)){
    	alert('비밀번호는 4회이상의 연속된 숫자를 사용할 수 없습니다.');
		reg_frm.user_pw.focus();
		return;
	}
	
	var checkCount = 0;
	if(/[0-9]/.test(document.reg_frm.user_pw.value)){ //숫자
	    checkCount++;
	}
	var pwChkCnt2 = 0;
	if(/[A-Z]/.test(document.reg_frm.user_pw.value)){ //대문자
	    checkCount++;
	}
	var pwChkCnt3 = 0;
	if(/[~!@\#$%<>^&*\()\-=+_\’]/.test(document.reg_frm.user_pw.value)){ //특수문자
	    checkCount++;
	}
	if(/[a-z]/.test(document.reg_frm.user_pw.value)){ //소문자
	    checkCount++;
	}
	
	console.log("조합 수 :", checkCount);
	if(checkCount <= 2){
	    alert('비밀번호는 영문 대/소문자, 숫자, 특수문자 중 3개이상의 조합이여야만 합니다.');
		reg_frm.user_pw.focus();
		return;
	}
	if(document.reg_frm.user_pw2.value != document.reg_frm.user_pw.value){
		alert("패스워드가 일치하지 않습니다.");
		reg_frm.user_pw2.focus();
		return;
	}	
	if(document.reg_frm.user_name.value.length == 0){
		alert("이름을 입력하세요.");
		reg_frm.user_name.focus();
		return;
	}	
	if(document.reg_frm.user_nick.value.length == 0){
		alert("닉네임을 입력하세요.");
		reg_frm.user_nick.focus();
		return;
	}	
	if(document.reg_frm.user_nick.value.length >= 7){
		alert("닉네임은  6글자까지 가능합니다.");
		reg_frm.user_nick.focus();
		return;
	}	
	if(document.reg_frm.user_addr.value.length == 0){
		alert("주소를 입력하세요.");
		reg_frm.user_addr.focus();
		return;
	}	
	if(document.reg_frm.phonenum.value.length == 0){
		alert("전화번호를 입력하세요.");
		reg_frm.phonenum.focus();
		return;
	}	
	if(!/01[01689][1-9]{1}[0-9]{2,3}[0-9]{4}$/.test(document.reg_frm.phonenum.value)){
    	alert("휴대폰 번호 양식이 아닙니다.");
		return;
	}
	document.reg_frm.submit();
}

function email_change(){
	if(document.reg_frm.email.options[document.reg_frm.email.selectedIndex].value == '0'){
		document.reg_frm.user_email2.disabled = true; 
 		document.reg_frm.user_email2.value = "";
		return;
	}

	if(document.reg_frm.email.options[document.reg_frm.email.selectedIndex].value == '9'){ 
		document.reg_frm.user_email2.disabled = false;
 		document.reg_frm.user_email2.value = "";
 		document.reg_frm.user_email2.focus();
		return;  
	} else { 
		document.reg_frm.user_email2.disabled = true;
 		document.reg_frm.user_email2.value = document.reg_frm.email.options[document.reg_frm.email.selectedIndex].value;
		return;
	} 
	document.reg_frm.submit();
}