package member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import myUtil.HanConv;

public class MemberDBBean {
	
private static MemberDBBean instance = new MemberDBBean();
	
	public static MemberDBBean getInstance() {
		return instance;
	}
	
	public Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/oracle");
		
		return ds.getConnection();
	}
	
	public int insertMember(MemberBean member) throws Exception{
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "";
		
		try {
			con = getConnection();						
			sql = "insert into usertable(user_nick, user_pw, user_name, reg_date, up_date, phonenum, mbti"
					+ ", user_email, user_sex, user_id, user_email2) "
					+ "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, HanConv.toKor(member.getUser_nick()));
			pstmt.setString(2, member.getUser_pw());
			pstmt.setString(3, HanConv.toKor(member.getUser_name()));
			pstmt.setTimestamp(4, member.getReg_date());
			pstmt.setTimestamp(5, member.getUp_date());
			pstmt.setString(6, member.getPhonenum());
			pstmt.setString(7, member.getMbti());
			pstmt.setString(8, member.getUser_email());
			pstmt.setString(9, HanConv.toKor(member.getUser_sex()));
			pstmt.setString(10, member.getUser_id());
			pstmt.setString(11, member.getUser_email2());
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return 1;
	}
	
	
	public int confirmID(String id) throws Exception{
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select user_id from usertable where user_id = ?";
		int re = -1;
		
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				re = 1;
			} else {
				re = -1;
			}
			rs.close();
			pstmt.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return re;
	}
	public int userCheck(String id, String pwd) throws Exception{
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select user_pw from usertable where user_id = ?";
		String db_user_pw;
		int re = -1;
		
		try{
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				db_user_pw = rs.getString("user_pw");
				if(db_user_pw.equals(pwd)) {
					re = 1;
				} else {
					re = 0;
				}
			}else {
				re = -1;
			}
			rs.close();
			pstmt.close();
			con.close();
		}catch(Exception e) {
		}
		return re;
	}
	public MemberBean getMember(String id) throws Exception{
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from usertable where user_id = ?";
		MemberBean member = null;
		
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				member = new MemberBean();
				member.setUser_nick(rs.getString("user_nick"));
				member.setUser_pw(rs.getNString("user_pw"));
				member.setUser_name(rs.getString("user_name"));
				member.setPhonenum(rs.getString("phonenum"));
				member.setMbti(rs.getString("mbti"));
				member.setUser_email(rs.getString("user_email"));
				member.setUser_sex(rs.getString("user_sex"));
				member.setUser_id(rs.getString("user_id"));
				member.setUser_email2(rs.getString("user_email2"));
			}
			rs.close();
			pstmt.close();
			con.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return member;
	}
}

