package board;
import java.sql.Timestamp;
public class BoardBean {
	private int b_no;  //게시글 번호
	private String user_nick; //유저명
	private Timestamp date; //작성날짜
	private int count; //조회수
	private int good; //추천수
	private int bad;  //비추천수
	private String title; // 제목
	private String content; // 내용
	private String board_type; // 게시판타입
	private String c_content;
	private Timestamp c_time;
	private String pwd;
	private String c_user_nick; // 댓글 작성자 닉네임
	private int c_no;//댓글작성순서 번호
	
	//페이징 처리를 위한 변수
	public static int pageSize = 20;
	public static int pageCount = 100;
	public static int pageNum = 1;
	
	
	public static String free_pageNumber(int limit, String col, String content) {
		String str = "";
		int temp = (pageNum - 1) % limit;
		int startPage = pageNum - temp;
		if(startPage - limit > 0) {
			str = "<a href='free_board.jsp?pageNum=" + (startPage - 1) + "&search_col="+ col +"&search_content="+ content +"' class='prev'>이전</a>&nbsp;&nbsp;";
		}
		for(int i = startPage; i < (startPage + limit); i++) {
			if(i == pageNum) {
				str += "<a href='free_board.jsp?pageNum=" + i + "&search_col="+ col +"&search_content="+ content +"' class='onPage'>" + i + "</a>&nbsp;&nbsp;";
			} else {
				str += "<a href='free_board.jsp?pageNum=" + i + "&search_col="+ col +"&search_content="+ content +"' class='not_onPage'>" + i + "</a>&nbsp;&nbsp;";
			}
			 
			if(i >= pageCount) {
				break;
			}
		}
		
		if((startPage + limit) <= pageCount) {
			str += "<a href='free_board.jsp?pageNum=" + (startPage + limit) + "&search_col="+ col +"&search_content="+ content +"' class='next'>다음</a>";
		}
		
		return str;
	}
	public static String anal_pageNumber(int limit, String col, String content) {
		String str = "";
		int temp = (pageNum - 1) % limit;
		int startPage = pageNum - temp;
		
		if(startPage - limit > 0) {
			str = "<a href='anal_board.jsp?pageNum=" + (startPage - 1) + "&search_col="+ col +"&search_content="+ content +"' class='prev'>이전</a>&nbsp;&nbsp;";
		}
		
		for(int i = startPage; i < (startPage + limit); i++) {
			if(i == pageNum) {
				str += "<a href='anal_board.jsp?pageNum=" + i + "&search_col="+ col +"&search_content="+ content +"' class='onPage'>" + i + "</a>&nbsp;&nbsp;";
			} else {
				str += "<a href='anal_board.jsp?pageNum=" + i + "&search_col="+ col +"&search_content="+ content +"' class='not_onPage'>" + i + "</a>&nbsp;&nbsp;";
			}
			 
			if(i >= pageCount) {
				break;
			}
		}
		
		if((startPage + limit) <= pageCount) {
			str += "<a href='anal_board.jsp?pageNum=" + (startPage + limit) + "&search_col="+ col +"&search_content="+ content +"' class='next'>다음</a>";
		}
		
		return str;
	}
	public static String dipl_pageNumber(int limit, String col, String content) {
		String str = "";
		int temp = (pageNum - 1) % limit;
		int startPage = pageNum - temp;
		
		if(startPage - limit > 0) {
			str = "<a href='dipl_board.jsp?pageNum=" + (startPage - 1) + "&search_col="+ col +"&search_content="+ content +"' class='prev'>이전</a>&nbsp;&nbsp;";
		}
		
		for(int i = startPage; i < (startPage + limit); i++) {
			if(i == pageNum) {
				str += "<a href='dipl_board.jsp?pageNum=" + i + "&search_col="+ col +"&search_content="+ content +"' class='onPage'>" + i + "</a>&nbsp;&nbsp;";
			} else {
				str += "<a href='dipl_board.jsp?pageNum=" + i + "&search_col="+ col +"&search_content="+ content +"' class='not_onPage'>" + i + "</a>&nbsp;&nbsp;";
			}
			 
			if(i >= pageCount) {
				break;
			}
		}
		
		if((startPage + limit) <= pageCount) {
			str += "<a href='dipl_board.jsp?pageNum=" + (startPage + limit) + "&search_col="+ col +"&search_content="+ content +"' class='next'>다음</a>";
		}
		
		return str;
	}
	public static String admin_pageNumber(int limit, String col, String content) {
		String str = "";
		int temp = (pageNum - 1) % limit;
		int startPage = pageNum - temp;
		
		if(startPage - limit > 0) {
			str = "<a href='admin_board.jsp?pageNum=" + (startPage - 1) + "&search_col="+ col +"&search_content="+ content +"' class='prev'>이전</a>&nbsp;&nbsp;";
		}
		
		for(int i = startPage; i < (startPage + limit); i++) {
			if(i == pageNum) {
				str += "<a href='admin_board.jsp?pageNum=" + i + "&search_col="+ col +"&search_content="+ content +"' class='onPage'>" + i + "</a>&nbsp;&nbsp;";
			} else {
				str += "<a href='admin_board.jsp?pageNum=" + i + "&search_col="+ col +"&search_content="+ content +"' class='not_onPage'>" + i + "</a>&nbsp;&nbsp;";
			}
			 
			if(i >= pageCount) {
				break;
			}
		}
		
		if((startPage + limit) <= pageCount) {
			str += "<a href='admin_board.jsp?pageNum=" + (startPage + limit) + "&search_col="+ col +"&search_content="+ content +"' class='next'>다음</a>";
		}
		
		return str;
	}
	
	public static String exp_pageNumber(int limit, String col, String content) {
		String str = "";
		int temp = (pageNum - 1) % limit;
		int startPage = pageNum - temp;
		if(startPage - limit > 0) {
			str = "<a href='exp_board.jsp?pageNum=" + (startPage - 1) + "&search_col="+ col +"&search_content="+ content +"' class='prev'>이전</a>&nbsp;&nbsp;";
		}
		for(int i = startPage; i < (startPage + limit); i++) {
			if(i == pageNum) {
				str += "<a href='exp_board.jsp?pageNum=" + i + "&search_col="+ col +"&search_content="+ content +"' class='onPage'>" + i + "</a>&nbsp;&nbsp;";
			} else {
				str += "<a href='exp_board.jsp?pageNum=" + i + "&search_col="+ col +"&search_content="+ content +"' class='not_onPage'>" + i + "</a>&nbsp;&nbsp;";
			}
			 
			if(i >= pageCount) {
				break;
			}
		}
		
		if((startPage + limit) <= pageCount) {
			str += "<a href='exp_board.jsp?pageNum=" + (startPage + limit) + "&search_col="+ col +"&search_content="+ content +"' class='next'>다음</a>";
		}
		
		return str;
	}
	public int getC_no() {
		return c_no;
	}

	public void setC_no(int c_no) {
		this.c_no = c_no;
	}

	public String getC_user_nick() {
		return c_user_nick;
	}

	public void setC_user_nick(String c_user_nick) {
		this.c_user_nick = c_user_nick;
	}

	public String getPwd() {
		return pwd;
	}
	
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public String getC_content() {
		return c_content;
	}
	
	public void setC_content(String c_content) {
		this.c_content = c_content;
	}
	
	public Timestamp getC_time() {
		return c_time;
	}
	
	public void setC_time(Timestamp c_time) {
		this.c_time = c_time;
	}
	
	public String getUser_nick() {
		return user_nick;
	}
	
	public void setUser_nick(String user_nick) {
		this.user_nick = user_nick;
	}
	public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public Timestamp getDate() {
		return date;
	}
	public void setDate(Timestamp date) {
		this.date = date;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getGood() {
		return good;
	}
	public void setGood(int good) {
		this.good = good;
	}
	public int getBad() {
		return bad;
	}
	public void setBad(int bad) {
		this.bad = bad;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getBoard_type() {
		return board_type;
	}
	public void setBoard_type(String board_type) {
		this.board_type = board_type;
	}
}
