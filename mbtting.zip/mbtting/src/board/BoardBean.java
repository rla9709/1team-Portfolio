package board;
import java.sql.Timestamp;

public class BoardBean {
	private int b_no;  //게시글 번호
	private String user_nick; //유저명
	private Timestamp date; //작성날짜
	private int count; //조회수
	private int good; //추천수
	private int bad;  //비추천수
	private String title; // 제목
	private String content; // 내용
	private String board_type; // 게시판타입
	private String c_content;
	private Timestamp c_time;
	private String pwd;
	
	public String getPwd() {
		return pwd;
	}
	
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public String getC_content() {
		return c_content;
	}
	
	public void setC_content(String c_content) {
		this.c_content = c_content;
	}
	
	public Timestamp getC_time() {
		return c_time;
	}
	
	public void setC_time(Timestamp c_time) {
		this.c_time = c_time;
	}
	
	public String getUser_nick() {
		return user_nick;
	}
	
	public void setUser_nick(String user_nick) {
		this.user_nick = user_nick;
	}
	public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public Timestamp getDate() {
		return date;
	}
	public void setDate(Timestamp date) {
		this.date = date;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getGood() {
		return good;
	}
	public void setGood(int good) {
		this.good = good;
	}
	public int getBad() {
		return bad;
	}
	public void setBad(int bad) {
		this.bad = bad;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getBoard_type() {
		return board_type;
	}
	public void setBoard_type(String board_type) {
		this.board_type = board_type;
	}
}
