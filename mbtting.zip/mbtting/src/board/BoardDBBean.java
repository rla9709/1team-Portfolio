package board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import myUtil.HanConv;

public class BoardDBBean {
	private static BoardDBBean instance = new BoardDBBean();

	// 싱글톤
	public static BoardDBBean getInstance() {
		return instance;
	}

	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/oracle");

		return ds.getConnection();
	}

	// 게시판 글 작성하기
	public int insertBoard(BoardBean board, String nick) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int number;

		try {
			con = getConnection();
			sql = "select max(b_no) from board";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				number = rs.getInt(1) + 1;
			} else {
				number = 1;
			}

			sql = "insert into board values(?,?,?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, number);
			pstmt.setString(2, nick);
			pstmt.setTimestamp(3, board.getDate());
			pstmt.setInt(4, board.getCount());
			pstmt.setInt(5, board.getGood());
			pstmt.setString(6, HanConv.toKor(board.getTitle()));
			pstmt.setString(7, HanConv.toKor(board.getContent()));
			pstmt.setString(8, HanConv.toKor(board.getBoard_type()));
			pstmt.setString(9, board.getPwd());

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return 1;
	}
	
	// 게시판리스트 내용 자유게시판에 뿌리기
	public ArrayList<BoardBean> freelistBoard(String pageNumber, String search_col, String search_content) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "";
		ResultSet pageSet = null;
		int dbCount = 0;
		int absolutePage = 1;
		
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();
		try {
			con = getConnection();
			//stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			stmt = con.createStatement();
			try {
				if(search_content != null) {
					if(search_col.equals("title")) {
						sql = "select count(b_no) from board where board_type = 'free' and title like '%" + search_content + "%'";
					} else if(search_col.equals("writer")) {
						sql = "select count(b_no) from board where board_type = 'free' and user_nick like '%" + search_content + "%'";
					} else if(search_col.equals("content")) {
						sql = "select count(b_no) from board where board_type = 'free' and content like '%" + search_content + "%'";
					} else {
						sql = "select count(b_no) from board where board_type = 'free'";
					}
				} else {
					sql = "select count(b_no) from board where board_type = 'free'";
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			pageSet = stmt.executeQuery(sql);
			
			if(pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
				stmt.close();
			}
			
			if(dbCount % BoardBean.pageSize == 0) {
				BoardBean.pageCount = dbCount / BoardBean.pageSize;
			} else {
				BoardBean.pageCount = dbCount / BoardBean.pageSize + 1;
			}
			
			if(pageNumber != null) {
				BoardBean.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (BoardBean.pageNum - 1) * BoardBean.pageSize + 1;
			}
			
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			try {
				if(search_content != null) {
					if(search_col.equals("title")) {
						sql = "select * from board where board_type = 'free' and title like '%" + search_content + "%' order by b_no desc";
					} else if(search_col.equals("writer")) {
						sql = "select * from board where board_type = 'free' and user_nick like '%" + search_content + "%' order by b_no desc";
					} else if(search_col.equals("content")) {
						sql = "select * from board where board_type = 'free' and content like '%" + search_content + "%' order by b_no desc";
					} else {
						sql = "select * from board where board_type = 'free' order by b_no desc";
					}
				} else {
					sql = "select * from board where board_type = 'free' order by b_no desc";
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			rs = stmt.executeQuery(sql);
			// System.out.println(search_col);
			// System.out.println(search_content);
			if(rs.next()) {
				rs.absolute(absolutePage);
				int count = 0;
				while(count < BoardBean.pageSize) {
					BoardBean board = new BoardBean();
					board.setB_no(rs.getInt(1));
					board.setUser_nick(rs.getString(2));
					board.setDate(rs.getTimestamp(3));
					board.setCount(rs.getInt(4));
					board.setGood(rs.getInt(5));
					board.setTitle(rs.getString(6));
					board.setContent(rs.getString(7));
					board.setBoard_type(rs.getString(8));
					board.setPwd(rs.getString(9));

					boardList.add(board);
					if(rs.isLast()) {
						break;
					} else {
						rs.next();
					}
					count++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}

	// 게시판리스트 내용 분석형게시판에 뿌리기
	public ArrayList<BoardBean> anallistBoard(String pageNumber, String search_col, String search_content) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "";
		ResultSet pageSet = null;
		int dbCount = 0;
		int absolutePage = 1;
		
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();

		try {
			con = getConnection();
			//stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			stmt = con.createStatement();
			try {
				if(search_content != null) {
					if(search_col.equals("title")) {
						sql = "select count(b_no) from board where board_type = 'anal' and title like '%" + search_content + "%'";
					} else if(search_col.equals("writer")) {
						sql = "select count(b_no) from board where board_type = 'anal' and user_nick like '%" + search_content + "%'";
					} else if(search_col.equals("content")) {
						sql = "select count(b_no) from board where board_type = 'anal' and content like '%" + search_content + "%'";
					} else {
						sql = "select count(b_no) from board where board_type = 'anal'";
					}
				} else {
					sql = "select count(b_no) from board where board_type = 'anal'";
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			pageSet = stmt.executeQuery(sql);
			
			if(pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
				stmt.close();
			}
			
			if(dbCount % BoardBean.pageSize == 0) {
				BoardBean.pageCount = dbCount / BoardBean.pageSize;
			} else {
				BoardBean.pageCount = dbCount / BoardBean.pageSize + 1;
			}
			
			if(pageNumber != null) {
				BoardBean.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (BoardBean.pageNum - 1) * BoardBean.pageSize + 1;
			}
			
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			try {
				if(search_col != null && search_content != null) {
					if(search_col.equals("title")) {
						sql = "select * from board where board_type = 'anal' and title like '%" + search_content + "%' order by b_no desc";
					} else if(search_col.equals("writer")) {
						sql = "select * from board where board_type = 'anal' and user_nick like '%" + search_content + "%' order by b_no desc";
					} else if(search_col.equals("content")) {
						sql = "select * from board where board_type = 'anal' and content like '%" + search_content + "%' order by b_no desc";
					} else {
						sql = "select * from board where board_type = 'anal' order by b_no desc";
					}
				} else {
					sql = "select * from board where board_type = 'anal' order by b_no desc";
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			rs = stmt.executeQuery(sql);
			
			if(rs.next()) {
				rs.absolute(absolutePage);
				int count = 0;
				while(count < BoardBean.pageSize) {
					BoardBean board = new BoardBean();
					board.setB_no(rs.getInt(1));
					board.setUser_nick(rs.getString(2));
					board.setDate(rs.getTimestamp(3));
					board.setCount(rs.getInt(4));
					board.setGood(rs.getInt(5));
					board.setTitle(rs.getString(6));
					board.setContent(rs.getString(7));
					board.setBoard_type(rs.getString(8));
					board.setPwd(rs.getString(9));

					boardList.add(board);
					if(rs.isLast()) {
						break;
					} else {
						rs.next();
					}
					count++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}
	// 게시판 리스트 외교형 게시판에 내용 뿌리기
	public ArrayList<BoardBean> dipllistBoard(String pageNumber, String search_col, String search_content) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "";
		ResultSet pageSet = null;
		int dbCount = 0;
		int absolutePage = 1;
		
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();

		try {
			con = getConnection();
			//stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			stmt = con.createStatement();
			try {
				if(search_col != null && search_content != null) {
					if(search_col.equals("title")) {
						sql = "select count(b_no) from board where board_type = 'dipl' and title like '%" + search_content + "%'";
					} else if(search_col.equals("writer")) {
						sql = "select count(b_no) from board where board_type = 'dipl' and user_nick like '%" + search_content + "%'";
					} else if(search_col.equals("content")) {
						sql = "select count(b_no) from board where board_type = 'dipl' and content like '%" + search_content + "%'";
					} else {
						sql = "select count(b_no) from board where board_type = 'dipl'";
					}
				} else {
					sql = "select count(b_no) from board where board_type = 'dipl'";
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			pageSet = stmt.executeQuery(sql);
			
			if(pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
				stmt.close();
			}
			
			if(dbCount % BoardBean.pageSize == 0) {
				BoardBean.pageCount = dbCount / BoardBean.pageSize;
			} else {
				BoardBean.pageCount = dbCount / BoardBean.pageSize + 1;
			}
			
			if(pageNumber != null) {
				BoardBean.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (BoardBean.pageNum - 1) * BoardBean.pageSize + 1;
			}
			
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			try {
				if(search_col != null && search_content != null) {
					if(search_col.equals("title")) {
						sql = "select * from board where board_type = 'dipl' and title like '%" + search_content + "%' order by b_no desc";
					} else if(search_col.equals("writer")) {
						sql = "select * from board where board_type = 'dipl' and user_nick like '%" + search_content + "%' order by b_no desc";
					} else if(search_col.equals("content")) {
						sql = "select * from board where board_type = 'dipl' and content like '%" + search_content + "%' order by b_no desc";
					} else {
						sql = "select * from board where board_type = 'dipl' order by b_no desc";
					}
				} else {
					sql = "select * from board where board_type = 'dipl' order by b_no desc";
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			rs = stmt.executeQuery(sql);
			
			if(rs.next()) {
				rs.absolute(absolutePage);
				int count = 0;
				while(count < BoardBean.pageSize) {
					BoardBean board = new BoardBean();
					board.setB_no(rs.getInt(1));
					board.setUser_nick(rs.getString(2));
					board.setDate(rs.getTimestamp(3));
					board.setCount(rs.getInt(4));
					board.setGood(rs.getInt(5));
					board.setTitle(rs.getString(6));
					board.setContent(rs.getString(7));
					board.setBoard_type(rs.getString(8));
					board.setPwd(rs.getString(9));

					boardList.add(board);
					if(rs.isLast()) {
						break;
					} else {
						rs.next();
					}
					count++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}
	// 게시판리스트 내용 관리자형게시판에 뿌리기
	public ArrayList<BoardBean> adminlistBoard(String pageNumber, String search_col, String search_content) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "";
		ResultSet pageSet = null;
		int dbCount = 0;
		int absolutePage = 1;
		
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();

		try {
			con = getConnection();
			//stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			stmt = con.createStatement();
			try {
				if(search_col != null && search_content != null) {
					if(search_col.equals("title")) {
						sql = "select count(b_no) from board where board_type = 'admin' and title like '%" + search_content + "%'";
					} else if(search_col.equals("writer")) {
						sql = "select count(b_no) from board where board_type = 'admin' and user_nick like '%" + search_content + "%'";
					} else if(search_col.equals("content")) {
						sql = "select count(b_no) from board where board_type = 'admin' and content like '%" + search_content + "%'";
					} else {
						sql = "select count(b_no) from board where board_type = 'free'";
					}
				} else {
					sql = "select count(b_no) from board where board_type = 'free'";
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			pageSet = stmt.executeQuery(sql);
			
			if(pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
				stmt.close();
			}
			
			if(dbCount % BoardBean.pageSize == 0) {
				BoardBean.pageCount = dbCount / BoardBean.pageSize;
			} else {
				BoardBean.pageCount = dbCount / BoardBean.pageSize + 1;
			}
			
			if(pageNumber != null) {
				BoardBean.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (BoardBean.pageNum - 1) * BoardBean.pageSize + 1;
			}
			
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			try {
				if(search_col != null && search_content != null) {
					if(search_col.equals("title")) {
						sql = "select * from board where board_type = 'admin' and title like '%" + search_content + "%' order by b_no desc";
					} else if(search_col.equals("writer")) {
						sql = "select * from board where board_type = 'admin' and user_nick like '%" + search_content + "%' order by b_no desc";
					} else if(search_col.equals("content")) {
						sql = "select * from board where board_type = 'admin' and content like '%" + search_content + "%' order by b_no desc";
					} else {
						sql = "select * from board where board_type = 'admin' order by b_no desc";
					}
				} else {
					sql = "select * from board where board_type = 'admin' order by b_no desc";
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			rs = stmt.executeQuery(sql);
			
			if(rs.next()) {
				rs.absolute(absolutePage);
				int count = 0;
				while(count < BoardBean.pageSize) {
					BoardBean board = new BoardBean();
					board.setB_no(rs.getInt(1));
					board.setUser_nick(rs.getString(2));
					board.setDate(rs.getTimestamp(3));
					board.setCount(rs.getInt(4));
					board.setGood(rs.getInt(5));
					board.setTitle(rs.getString(6));
					board.setContent(rs.getString(7));
					board.setBoard_type(rs.getString(8));
					board.setPwd(rs.getString(9));

					boardList.add(board);
					if(rs.isLast()) {
						break;
					} else {
						rs.next();
					}
					count++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}

	// 게시판리스트 내용 탐험가형게시판에 뿌리기
	public ArrayList<BoardBean> explistBoard(String pageNumber, String search_col, String search_content) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "";
		ResultSet pageSet = null;
		int dbCount = 0;
		int absolutePage = 1;
		
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();

		try {
			con = getConnection();
			//stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			stmt = con.createStatement();
			try {
				if(search_col != null && search_content != null) {
					if(search_col.equals("title")) {
						sql = "select count(b_no) from board where board_type = 'exp' and title like '%" + search_content + "%'";
					} else if(search_col.equals("writer")) {
						sql = "select count(b_no) from board where board_type = 'exp' and user_nick like '%" + search_content + "%'";
					} else if(search_col.equals("content")) {
						sql = "select count(b_no) from board where board_type = 'exp' and content like '%" + search_content + "%'";
					} else {
						sql = "select count(b_no) from board where board_type = 'exp'";
					}
				} else {
					sql = "select count(b_no) from board where board_type = 'exp'";
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			pageSet = stmt.executeQuery(sql);
			
			if(pageSet.next()) {
				dbCount = pageSet.getInt(1);
				pageSet.close();
				stmt.close();
			}
			
			if(dbCount % BoardBean.pageSize == 0) {
				BoardBean.pageCount = dbCount / BoardBean.pageSize;
			} else {
				BoardBean.pageCount = dbCount / BoardBean.pageSize;
			}
			
			if(pageNumber != null) {
				BoardBean.pageNum = Integer.parseInt(pageNumber);
				absolutePage = (BoardBean.pageNum - 1) * BoardBean.pageSize + 1;
			}
			
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			if(search_col != null && search_content != null) {
				if(search_col.equals("title")) {
					sql = "select * from board where board_type = 'exp' and title like '%" + search_content + "%' order by b_no desc";
				} else if(search_col.equals("writer")) {
					sql = "select * from board where board_type = 'exp' and user_nick like '%" + search_content + "%' order by b_no desc";
				} else if(search_col.equals("content")) {
					sql = "select * from board where board_type = 'exp' and content like '%" + search_content + "%' order by b_no desc";
				} else {
					sql = "select * from board where board_type = 'exp' order by b_no desc";
				}
			} else {
				sql = "select * from board where board_type = 'exp' order by b_no desc";
			}
			rs = stmt.executeQuery(sql);
			
			if(rs.next()) {
				rs.absolute(absolutePage);
				int count = 0;
				while(count < BoardBean.pageSize) {
					BoardBean board = new BoardBean();
					board.setB_no(rs.getInt(1));
					board.setUser_nick(rs.getString(2));
					board.setDate(rs.getTimestamp(3));
					board.setCount(rs.getInt(4));
					board.setGood(rs.getInt(5));
					board.setTitle(rs.getString(6));
					board.setContent(rs.getString(7));
					board.setBoard_type(rs.getString(8));
					board.setPwd(rs.getString(9));

					boardList.add(board);
					if(rs.isLast()) {
						break;
					} else {
						rs.next();
					}
					count++;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}
	
	// 조회수 증가하는 메서드
	public void updateBoardCount(int b_no) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "";
		try {
			con = getConnection();
			sql = "update board set count = count + 1 where b_no=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	// 게시글 상세 확인 메서드
	public BoardBean getBoard(int b_no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		BoardBean board = null;

		try {
			con = getConnection();
			sql = "select * from board where b_no=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				board = new BoardBean();
				board.setB_no(rs.getInt(1));
				board.setUser_nick(rs.getString(2));
				board.setDate(rs.getTimestamp(3));
				board.setCount(rs.getInt(4));
				board.setGood(rs.getInt(5));
				board.setTitle(rs.getString(6));
				board.setContent(rs.getString(7));
				board.setBoard_type(rs.getString(8));
				board.setPwd(rs.getString(9));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return board;
	}
	
	//게시글 수정하는 메서드
	public int editBoard(BoardBean board) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int re = -1;
		String pwd = "";
		
		try {
			con = getConnection();
			sql = "select pwd from board where b_no = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, board.getB_no());
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				pwd = rs.getString(1);
				
				if(!pwd.equals(board.getPwd())) {
					// 비밀번호가 다를 경우
					re = 0;
				} else {
					sql = "update board set title = ?, content = ?, board_type = ? where b_no = ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, HanConv.toKor(board.getTitle()));
					pstmt.setString(2, HanConv.toKor(board.getContent()));
					pstmt.setString(3, board.getBoard_type());
					pstmt.setInt(4, board.getB_no());
					pstmt.executeUpdate();
					re = 1;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}
	
	// 게시글 삭제하는 메서드
	public int deleteBoard(int b_no, String pwd) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int re = -1;
		String b_pwd = "";
		
		try {
			con = getConnection();
			sql = "select pwd from board where b_no = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				b_pwd = rs.getString(1);
				
				if (!b_pwd.equals(pwd)) {
					re = 0;
				} else {
					// 댓글 먼저 삭제한 후 글 내용 삭제(fk로 종속되어있음), 추천테이블에도 해당 글 삭제
					sql = "delete goodcheck where good_b_no = ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, b_no);
					pstmt.executeUpdate();
					
					sql = "delete boardcomment where b_no = ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, b_no);
					pstmt.executeUpdate();
					
					sql = "delete board where b_no = ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, b_no);
					pstmt.executeUpdate();
					re = 1;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}
	// goodcheck 테이블에 번호랑 추천누른 사람 계정 저장하기
	public int insertGoodcheck(String nick, int b_no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "";
		int re = 0;
		try {
			con = getConnection();
			sql = "insert into goodcheck values(?,?)";
			pstmt = con.prepareStatement(sql);

			pstmt.setString(1, nick);
			pstmt.setInt(2, b_no);
			pstmt.executeUpdate();
			re = 1;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}
	// goodcheck 테이블에서 번호에 저장된 닉네임값 가져오기 (추천 한 계정 당 한번만 받기위한 메서드)
	public String getGoodNick(int b_no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		String nick = "";
		
		try {
			con = getConnection();
			sql = "select GOOD_USER_NICK from goodcheck where GOOD_B_NO=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				nick = rs.getString(1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return nick;
	}
	
	// 추천 갯수 올리는 메서드
	public void updateGoodCount(int b_no) throws SQLException {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "";
		try {
			con = getConnection();
			sql = "update board set good = good + 1 where b_no=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	//////////////////////////////////////////////////////// 댓글
	//////////////////////////////////////////////////////// 메서드///////////////////////////////////////////////////////////////

	// 댓글 테이블에 넣어주는 메서드
	public int insertComment(BoardBean board, int b_no, String nick) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int number;
		try {
			con = getConnection();
			
			sql = "select max(c_no) from boardcomment";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				number = rs.getInt(1) + 1;
			} else {
				number = 1;
			}

			sql = "insert into boardcomment values(?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, b_no);
			pstmt.setString(2, nick);
			pstmt.setString(3, HanConv.toKor(board.getC_content()));
			pstmt.setTimestamp(4, board.getC_time());
			pstmt.setInt(5, number);

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return 1;
	}

	// 댓글리스트로 받아서 화면에 뿌려주는 메서드
	public ArrayList<BoardBean> listCommnet(int b_no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();

		try {
			con = getConnection();
			sql = "select * from boardcomment where b_no=? order by c_time";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				BoardBean board = new BoardBean();
				board.setB_no(rs.getInt(1));
				board.setC_user_nick(rs.getString(2));
				board.setC_content(rs.getString(3));
				board.setC_time(rs.getTimestamp(4));
				board.setC_no(rs.getInt(5));

				boardList.add(board);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}
	// 댓글 총 갯수 세는 메서드
	public int countcomment(int b_no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int cnt = 0;

		try {
			con = getConnection();
			sql = "select count(*) from boardcomment where b_no=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			rs = pstmt.executeQuery();
			
			if(rs != null &&rs.next()) {
				cnt = rs.getInt(1);
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return cnt;
	}
	//댓글 삭제하는 메소드
	public int deleteComment(int c_no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "";
		int re = -1;
		
		try {
			con = getConnection();
			sql = "delete boardcomment where c_no = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, c_no);
			pstmt.executeUpdate();
			re = 1;
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return re;
	}
}	
	
	///////////////////////////////////////////////////////////게시판 검색 기능 메서드/////////////////////////////////////////////
