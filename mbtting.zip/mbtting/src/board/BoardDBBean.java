package board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import myUtil.HanConv;

public class BoardDBBean {
	private static BoardDBBean instance = new BoardDBBean();

	// 싱글톤
	public static BoardDBBean getInstance() {
		return instance;
	}

	public Connection getConnection() throws Exception {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/oracle");

		return ds.getConnection();
	}

	// 게시판 글 작성하기
	public int insertBoard(BoardBean board, String nick) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int number;

		try {
			con = getConnection();
			sql = "select max(b_no) from board";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				number = rs.getInt(1) + 1;
			} else {
				number = 1;
			}

			sql = "insert into board values(?,?,?,?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, number);
			pstmt.setString(2, nick);
			pstmt.setTimestamp(3, board.getDate());
			pstmt.setInt(4, board.getCount());
			pstmt.setInt(5, board.getGood());
			pstmt.setInt(6, board.getBad());
			pstmt.setString(7, HanConv.toKor(board.getTitle()));
			pstmt.setString(8, HanConv.toKor(board.getContent()));
			pstmt.setString(9, HanConv.toKor(board.getBoard_type()));
			pstmt.setString(10, board.getPwd());

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return 1;
	}

	// 게시판리스트 내용 자유게시판에 뿌리기
	public ArrayList<BoardBean> freelistBoard() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();

		try {
			con = getConnection();
			sql = "select * from board where board_type = 'free' order by b_no desc";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				BoardBean board = new BoardBean();
				board.setB_no(rs.getInt(1));
				board.setUser_nick(rs.getString(2));
				board.setDate(rs.getTimestamp(3));
				board.setCount(rs.getInt(4));
				board.setGood(rs.getInt(5));
				board.setBad(rs.getInt(6));
				board.setTitle(rs.getString(7));
				board.setContent(rs.getString(8));
				board.setBoard_type(rs.getString(9));
				board.setPwd(rs.getString(10));

				boardList.add(board);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}

	// 게시판리스트 내용 분석형게시판에 뿌리기
	public ArrayList<BoardBean> anallistBoard() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();

		try {
			con = getConnection();
			sql = "select * from board where board_type = 'anal' order by b_no desc";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				BoardBean board = new BoardBean();
				board.setB_no(rs.getInt(1));
				board.setUser_nick(rs.getString(2));
				board.setDate(rs.getTimestamp(3));
				board.setCount(rs.getInt(4));
				board.setGood(rs.getInt(5));
				board.setBad(rs.getInt(6));
				board.setTitle(rs.getString(7));
				board.setContent(rs.getString(8));
				board.setBoard_type(rs.getString(9));
				board.setPwd(rs.getString(10));

				boardList.add(board);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}

	// 게시판리스트 내용 외교형게시판에 뿌리기
	public ArrayList<BoardBean> dipllistBoard() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();

		try {
			con = getConnection();
			sql = "select * from board where board_type = 'dipl' order by b_no desc";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				BoardBean board = new BoardBean();
				board.setB_no(rs.getInt(1));
				board.setUser_nick(rs.getString(2));
				board.setDate(rs.getTimestamp(3));
				board.setCount(rs.getInt(4));
				board.setGood(rs.getInt(5));
				board.setBad(rs.getInt(6));
				board.setTitle(rs.getString(7));
				board.setContent(rs.getString(8));
				board.setBoard_type(rs.getString(9));
				board.setPwd(rs.getString(10));

				boardList.add(board);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}

	// 게시판리스트 내용 관리자형게시판에 뿌리기
	public ArrayList<BoardBean> adminlistBoard() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();

		try {
			con = getConnection();
			sql = "select * from board where board_type = 'admin' order by b_no desc";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				BoardBean board = new BoardBean();
				board.setB_no(rs.getInt(1));
				board.setUser_nick(rs.getString(2));
				board.setDate(rs.getTimestamp(3));
				board.setCount(rs.getInt(4));
				board.setGood(rs.getInt(5));
				board.setBad(rs.getInt(6));
				board.setTitle(rs.getString(7));
				board.setContent(rs.getString(8));
				board.setBoard_type(rs.getString(9));
				board.setPwd(rs.getString(10));

				boardList.add(board);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}

	// 게시판리스트 내용 탐험가형게시판에 뿌리기
	public ArrayList<BoardBean> explistBoard() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();

		try {
			con = getConnection();
			sql = "select * from board where board_type = 'exp' order by b_no desc";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				BoardBean board = new BoardBean();
				board.setB_no(rs.getInt(1));
				board.setUser_nick(rs.getString(2));
				board.setDate(rs.getTimestamp(3));
				board.setCount(rs.getInt(4));
				board.setGood(rs.getInt(5));
				board.setBad(rs.getInt(6));
				board.setTitle(rs.getString(7));
				board.setContent(rs.getString(8));
				board.setBoard_type(rs.getString(9));
				board.setPwd(rs.getString(10));

				boardList.add(board);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}

	public BoardBean getBoard(int b_no, boolean countadd) {
		Connection con = null;
		PreparedStatement pstmtUp = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		BoardBean board = null;

		try {
			con = getConnection();
			if (countadd == true) {
				sql = "update board set count = count + 1 where b_no=?";
				pstmtUp = con.prepareStatement(sql);
				pstmtUp.setInt(1, b_no);
				pstmtUp.executeUpdate();
				pstmtUp.close();
			}
			sql = "select * from board where b_no=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				board = new BoardBean();
				board.setB_no(rs.getInt(1));
				board.setUser_nick(rs.getString(2));
				board.setDate(rs.getTimestamp(3));
				board.setCount(rs.getInt(4));
				board.setGood(rs.getInt(5));
				board.setBad(rs.getInt(6));
				board.setTitle(rs.getString(7));
				board.setContent(rs.getString(8));
				board.setBoard_type(rs.getString(9));
				board.setPwd(rs.getString(10));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return board;
	}
	

	//////////////////////////////////////////////////////// 댓글
	//////////////////////////////////////////////////////// 메서드///////////////////////////////////////////////////////////////

	// 댓글 테이블에 넣어주는 메서드
	public int insertComment(BoardBean board, int b_no, String nick) {
		Connection con = null;
		PreparedStatement pstmt = null;

		String sql = "";

		try {
			con = getConnection();
			sql = "insert into boardcomment values(?,?,?,?)";
			pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, b_no);
			pstmt.setString(2, nick);
			pstmt.setString(3, HanConv.toKor(board.getC_content()));
			pstmt.setTimestamp(4, board.getC_time());

			pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return 1;
	}

	// 댓글리스트로 받아서 화면에 뿌려주는 메서드
	public ArrayList<BoardBean> listCommnet(int b_no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		ArrayList<BoardBean> boardList = new ArrayList<BoardBean>();

		try {
			con = getConnection();
			sql = "select * from boardcomment where b_no=? order by c_time";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				BoardBean board = new BoardBean();
				board.setB_no(rs.getInt(1));
				board.setUser_nick(rs.getString(2));
				board.setC_content(rs.getString(3));
				board.setC_time(rs.getTimestamp(4));

				boardList.add(board);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return boardList;
	}
	// 댓글 총 갯수 세는 메서드
	public int countcomment(int b_no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		int cnt = 0;

		try {
			con = getConnection();
			sql = "select count(*) from boardcomment where b_no=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, b_no);
			rs = pstmt.executeQuery();
			
			if(rs != null &&rs.next()) {
				cnt = rs.getInt(1);
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return cnt;
	}
}